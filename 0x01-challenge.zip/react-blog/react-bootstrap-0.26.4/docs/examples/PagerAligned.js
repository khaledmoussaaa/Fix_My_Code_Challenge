const pagerInstance = (
  <Pager>
    <PageItem previous href="#">&larr; Previous Page</PageItem>
    <PageItem next href="#">Next Page &rarr;</PageItem>
  </Pager>
);

React.render(pagerInstance, mountNode);
