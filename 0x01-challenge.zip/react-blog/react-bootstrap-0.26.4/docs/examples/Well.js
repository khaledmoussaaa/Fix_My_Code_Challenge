const wellInstance = (
  <Well>Look I'm in a well!</Well>
);

React.render(wellInstance, mountNode);
